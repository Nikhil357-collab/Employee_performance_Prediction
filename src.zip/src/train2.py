import os
import json
import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.inspection import permutation_importance

from preprocess import create_preprocessor

# -----------------------------
# 1. PATH SETUP
# -----------------------------
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(CURRENT_DIR)

data_path = os.path.join(BASE_DIR, "data", "raw", "employee_data.csv")
model_dir = os.path.join(BASE_DIR, "models")

model_path = os.path.join(model_dir, "model.pkl")
features_path = os.path.join(model_dir, "features.json")
importance_path = os.path.join(model_dir, "feature_importance.json")
fairness_path = os.path.join(model_dir, "fairness.json")

os.makedirs(model_dir, exist_ok=True)

print("\n===== PATH INFO =====")
print("BASE_DIR:", BASE_DIR)
print("DATA PATH:", data_path)

# -----------------------------
# 2. LOAD DATA
# -----------------------------
if not os.path.exists(data_path):
    raise FileNotFoundError(f"Dataset not found at: {data_path}")

df = pd.read_csv(data_path)

print("\n===== DATA INFO =====")
print("Shape:", df.shape)

# -----------------------------
# 3. FEATURES & TARGET
# -----------------------------
X = df.drop(columns=["perf_band_next", "employee_id"], errors="ignore")
y = df["perf_band_next"]

# -----------------------------
# 4. TRAIN-TEST SPLIT
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    stratify=y,
    random_state=42
)

print("\nTrain size:", X_train.shape)
print("Test size:", X_test.shape)

# -----------------------------
# 5. SAVE FEATURE SCHEMA
# -----------------------------
feature_cols = X_train.columns.tolist()

with open(features_path, "w") as f:
    json.dump(feature_cols, f)

print("✅ features.json saved")

# -----------------------------
# 6. PREPROCESSING
# -----------------------------
pre = create_preprocessor(X_train)

# -----------------------------
# 7. MODEL PIPELINE
# -----------------------------
model = Pipeline([
    ("pre", pre),
    ("clf", RandomForestClassifier(
        n_estimators=300,
        random_state=42,
        n_jobs=-1,
        class_weight="balanced"
    ))
])

# -----------------------------
# 8. TRAIN MODEL
# -----------------------------
model.fit(X_train, y_train)

# -----------------------------
# 9. SAVE MODEL
# -----------------------------
joblib.dump(model, model_path)
print("✅ Model saved")

# -----------------------------
# 10. PREDICT (SAFE)
# -----------------------------
y_pred = model.predict(X_test)

print("\nPrediction length:", len(y_pred))
print("X_test length:", len(X_test))

# -----------------------------
# 11. FEATURE IMPORTANCE (FIXED)
# -----------------------------
print("\n===== FEATURE IMPORTANCE =====")

r = permutation_importance(
    model,
    X_test,
    y_test,
    n_repeats=5,
    random_state=42,
    scoring="f1_macro"
)

# ✅ CRITICAL FIX: use transformed feature names
feature_names = model.named_steps["pre"].get_feature_names_out()

# ensure same length
assert len(feature_names) == len(r.importances_mean), "Feature mismatch error!"

imp = pd.Series(r.importances_mean, index=feature_names).sort_values(ascending=False)

print(imp.head(10))
print("Importances length:", len(r.importances_mean))
print("Feature names length:", len(feature_names))

# save
imp.to_json(importance_path)
print("✅ Feature importance saved")

# -----------------------------
# 12. FAIRNESS REPORT (SAFE)
# -----------------------------
print("\n===== FAIRNESS REPORT =====")

def group_report(df_true, y_pred, group_col, positive_class='H'):
    out = []

    df_temp = df_true.copy()
    df_temp["pred"] = y_pred  # ✅ safe alignment

    for g in df_temp[group_col].dropna().unique():
        subset = df_temp[df_temp[group_col] == g]

        if len(subset) == 0:
            continue

        selection_rate = (subset["pred"] == positive_class).mean()
        count = len(subset)

        out.append((g, round(selection_rate, 3), count))

    result = pd.DataFrame(out, columns=[group_col, "selection_rate", "count"])

    if len(result) > 1:
        min_rate = result["selection_rate"].min()
        max_rate = result["selection_rate"].max()

        ratio = min_rate / max_rate if max_rate > 0 else 0

        print(result)
        print(f"\nMin/Max ratio: {ratio:.3f}")

        if ratio < 0.80:
            print("⚠️ WARNING: Fails 80% rule")
    else:
        print(result)

    return result

# run fairness
if "gender" in X_test.columns:
    fairness_df = group_report(X_test, y_pred, "gender")

    fairness_df.to_json(fairness_path, orient="records")
    print("✅ Fairness report saved")
else:
    print("⚠️ gender column not found")

print("\n✅ TRAINING COMPLETE")