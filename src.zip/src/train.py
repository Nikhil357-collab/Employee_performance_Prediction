import os
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from preprocess import create_preprocessor

# -----------------------------
# 1. Resolve project root safely
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(CURRENT_DIR)

data_path = os.path.join(BASE_DIR, "data", "raw", "employee_data.csv")

model_dir = os.path.join(BASE_DIR, "models")
model_path = os.path.join(model_dir, "model.pkl")
os.makedirs(model_dir, exist_ok=True)
# Debug (keep for now)
print("BASE_DIR:", BASE_DIR)
print("DATA PATH:", data_path)
print("MODEL PATH:", model_path)

# -----------------------------
# 2. Ensure directories exist
# -----------------------------
os.makedirs(os.path.join(BASE_DIR, "models"), exist_ok=True)
# -----------------------------
# 3. Load dataset
# -----------------------------
if not os.path.exists(data_path):
    raise FileNotFoundError(f"Dataset not found at: {data_path}")

df = pd.read_csv(data_path)

# -----------------------------
# 4. Features & Target
# -----------------------------
X = df.drop(columns=["perf_band_next", "employee_id"], errors="ignore")
y = df["perf_band_next"]
# -----------------------------
# 5. Train-test split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    stratify=y,
    random_state=42
)
#---------------------
import json

feature_cols = X_train.columns.tolist()
features_path = os.path.join(model_dir, "features.json")

with open(features_path, "w") as f:
    json.dump(feature_cols, f)

print("✅ features.json saved at:", features_path)
# -----------------------------
# 6. Preprocessing
# -----------------------------
pre = create_preprocessor(X_train)

# -----------------------------
# 7. Model pipeline
# -----------------------------
model = Pipeline([
    ("pre", pre),
    ("clf", RandomForestClassifier(
        n_estimators=300,
        random_state=42,
        n_jobs=-1
    ))
])

# -----------------------------
# 8. Train model
# -----------------------------
model.fit(X_train, y_train)

# -----------------------------
# 9. Save model
# -----------------------------
joblib.dump(model, model_path)

print(f"\n✅ Model successfully saved at:\n{model_path}")